from .wimi import Wimi

wimi = Wimi()